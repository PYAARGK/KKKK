import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        //fill the code;
      Scanner sc=new Scanner(System.in);
        int x,y,z,n,i=0;
      x=sc.nextInt();
      y=sc.nextInt();
      z=sc.nextInt();
      n=sc.nextInt();
      if(n<=x)
        i++;
      if(n<=y)
        i++;
      if(n<=z)
        i++;
      System.out.println(i);
    }
}
