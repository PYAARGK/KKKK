import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        //fill the code;
      Scanner input = new Scanner(System.in);
      int b= input.nextInt();
      int cy= input.nextInt();
      int x=b-cy;
      if(x<0)
      {
        int c = 100-b;
        int d = 100-cy;
        int ca = c-d;
        System.out.println(ca);
      }
      else
      {
        int c = 100-b;
        int d = cy;
        int ca = c+d;
        System.out.println(ca);
      }
       
    }
}
