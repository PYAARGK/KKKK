import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
       Scanner sathish=new Scanner(System.in);
      int a=sathish.nextInt();
      int b=sathish.nextInt();
      int c=sathish.nextInt();
      if (a<b){
        if(a<c){
          System.out.println("L1");
        }
        else
          System.out.println("L3");
      }
       else if (c<b){
        if(c<a){
          System.out.println("L3");
        }
        else
          System.out.println("L1");
      }
      else
        System.out.println("L2");
    }
}
