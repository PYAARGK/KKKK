import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
       Scanner sc=new Scanner(System.in);
      int a=sc.nextInt();
       int s=sc.nextInt();
      if(a==s)
      {
        System.out.printf("%d and %d are equal",a,s);
      }
    else if(a>s)
      {
        System.out.printf("%d greater than %d ",a,s);
    }
      else if(a<s)
      {
         System.out.printf("%d less than %d ",a,s);
      }
     
}
}
