import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        Scanner sathish=new Scanner(System.in);
      byte a=sathish.nextByte();
      if (a<=100 && a>=0)
      {
      	if(a==100)
          System.out.println("S");
        else if(a<=99 && a>=90)
          System.out.println("A");
        else if(a<=89 && a>=80)
          System.out.println("B");
        else if(a<=79 && a>=70)
          System.out.println("C");
        else if(a<=69 && a>=60)
          System.out.println("D");
        else if(a<=59 && a>=50)
          System.out.println("E");
        else 
          System.out.println("F");
      }
      else
        System.out.println("Invalid Input");
    }
}
