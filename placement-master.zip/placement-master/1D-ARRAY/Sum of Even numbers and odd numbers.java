import java.util.Scanner;
class Main
{
  public static void main(String args[])
  {
    Scanner sathish=new Scanner(System.in);
    int n=sathish.nextInt();
    int a[]=new int[n];
    for(int i=0;i<n;i++)
    {
       a[i]=sathish.nextInt();
    }
    int b=0,c=0;
    for(int i=0;i<n;i++){
      if((a[i]%2)==0){
       b=b+a[i];
      }
      else
      { 
      c=c+a[i];
      }
    
    }
    System.out.printf("The sum of the even numbers in the array is %d\n",b);
    System.out.printf("The sum of the odd numbers in the array is %d",c);
  }
}
