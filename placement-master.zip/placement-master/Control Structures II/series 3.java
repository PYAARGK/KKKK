import java.util.Scanner;
class Main
{
	public static void main(String args[])
	{
		Scanner sathish=new Scanner(System.in);
      int a=sathish.nextInt();
      int b=3,c=1;
      //System.out.print(b+" ");
      for (int i=0;i<a;i++){
        c=b*c;
        System.out.print(c+" ");
	}
}}
