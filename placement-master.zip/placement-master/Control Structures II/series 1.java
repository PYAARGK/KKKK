import java.util.Scanner;
class Main
{
	public static void main(String args[])
	{
		Scanner sathish=new Scanner(System.in);
      int a=sathish.nextInt();
      for (int i=1;i<a+1;i++){
      int b=i*i;
        System.out.printf("%d ",b);
      }
	}
}
