import java.util.Scanner;
class Main
{
	public static void main(String args[])
	{
		Scanner aa=new Scanner(System.in);
         String a=aa.next();
         String b=aa.next();
       System.out.print(a+b);


	}
}
