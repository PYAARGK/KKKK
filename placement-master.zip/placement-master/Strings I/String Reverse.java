import java.util.Scanner;
class Main
{
	public static void main(String args[])
	{
		Scanner sathish=new Scanner(System.in);
      String a=sathish.next();
      StringBuilder b=new StringBuilder();
      b.append(a);
      System.out.println(b.reverse());
	}
}
