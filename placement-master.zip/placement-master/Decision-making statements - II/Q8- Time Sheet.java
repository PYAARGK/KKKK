import java.util.Scanner;
class Main
{
    public static void main(String args[])
    {
        Scanner in =new Scanner(System.in);
        int a=in.nextInt();
        int b=in.nextInt();
        int c=in.nextInt();
        int d=in.nextInt();
        int e=in.nextInt();
        int f=in.nextInt();
        int g=in.nextInt();
      int a1,b1,c1,d1,e1,f1,g1,rate;
       a1=a*150;
       g1=g*125;
     
      if(b<=8)
      {
       b1=b*100;
      }
      else
      {
        int b2=0;
        b2=b-8;
         b1=8*100+b2*115;
      }
       if(c<=8)
      {
        c1=c*100;
      }
      else
      {
        int c2=0;
        c2=c-8;
         c1=8*100+c2*115;
      } if(d<=8)
      {
        d1=d*100;
      }
      else
      {
        int d2=0;
        d2=d-8;
         d1=8*100+d2*115;
      } if(e<=8)
      {
        e1=e*100;
      }
      else
      {
        int e2=0;
        e2=e-8;
         e1=8*100+e2*115;
      } if(f<=8)
      {
        f1=f*100;
      }
      else
      {
        int f2=0;
       f2=f-8;
         f1=8*100+f2*115;
      }
      int td=b+c+d+e+f;
      if(td>=40)
      {
      int tdr=td-40;
       rate=tdr*25;
      }
      else
      {
      int tdr=0;
        rate=0;
      }
      int tr=b1+c1+d1+e1+f1+a1+g1+rate;
      System.out.println(tr);
    }}
