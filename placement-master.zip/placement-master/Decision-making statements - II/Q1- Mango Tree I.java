 import java.util.Scanner;
class Main
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
      int row=in.nextInt();
      int column=in.nextInt();
      int tree=in.nextInt();
    int i=tree;
      if(i<=column)
      {
        System.out.println("Yes");
      }
    else  if(tree%column==0)
      {
            System.out.println("Yes");
      }
      else if((tree-1)%column==0)
      {
            System.out.println("Yes");
      }
      else
      {
            System.out.println("No");
}
}
}
