import java.util.Scanner;
class Main
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
      String S=in.next();
      int c =in.nextInt();
      switch(S)
      {
       case "front":
        if(c==1)
        {
        System.out.println("Left Handed");
        }
        else
        {
         System.out.println("Right Handed");
        }
      break;
      case "rear":
        if(c==1)
        {
        System.out.println("Right Handed");
        }
        else
        {
         System.out.println("Left Handed");
        }
       break;
      }
     
           
           
     
     
}
}
