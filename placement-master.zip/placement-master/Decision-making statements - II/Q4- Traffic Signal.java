import java.util.Scanner;
class Main
{
public static void main(String args[])
{
 Scanner ob=new Scanner(System.in);
      float speed=ob.nextFloat();
      float distance=ob.nextFloat();
      float time=ob.nextFloat();
      if(distance==1)
      {
      if(speed<time)
      {
       System.out.println("No");
      }
      else
      {
        System.out.println("Yes");
      }}
      else
      {
       System.out.println("No");  
      }
}
}
